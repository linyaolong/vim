### Expected behavior

<!-- What did you expect or want to happen? -->

### Steps to reproduce

<!--
For bugs please provide steps to reproduce the issue.

1. Please set `g:neomake_logfile`, e.g.
   `:let g:neomake_logfile = '/tmp/neomake.log'` first.
2. Look at the logfile for the generated output, which might help revealing the
   issue already.
   You can use `make tail_log` from Neomake's source directory
   for following the logfile in a separate terminal.
3. Please describe how you run Neomake: manually (how?), via automake config,
   or via some custom autocommand(s) (which?).
-->

### Output from (verbose) NeomakeInfo

<!--

1. Paste the output from `:verbose NeomakeInfo` here.
   You can use `:verbose NeomakeInfo!` (with a bang at the end) to copy it to
   your clipboard.

2. If relevant (it is always useful with bug reports) paste the contents of the
   logfile (via `g:neomake_logfile`).

-->
