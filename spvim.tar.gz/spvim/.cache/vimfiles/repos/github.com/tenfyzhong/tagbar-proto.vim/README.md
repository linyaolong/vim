# tagbar-proto.vim
protobuf for tagbar

# Install
I suggest you to use a plugin manager, such vim-plug or other.
- [vim-plug](https://github.com/junegunn/vim-plug)
```viml
Plug 'tenfyzhong/tagbar-proto.vim'
```
- Manual
```
git clone https://github.com/tenfyzhong/tagbar-proto.vim.git ~/.vim/bundle/tagbar-proto.vim
echo 'set rtp+=~/.vim/bundle/tagbar-proto.vim'
```

