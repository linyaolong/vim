<!--
Thank you for working on ComplateParameter!
Please include tests for the PR. 
-->

# Why this change is necessary and useful

<!--Please explain **in detail** why the changes in this PR are needed.-->
