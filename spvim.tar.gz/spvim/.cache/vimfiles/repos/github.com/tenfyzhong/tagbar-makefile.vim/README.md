# tagbar-makefile.vim
makefile for tagbar

# Install
I suggest you to use a plugin manager, such vim-plug or other.
- [vim-plug](https://github.com/junegunn/vim-plug)
```viml
Plug 'tenfyzhong/tagbar-makefile.vim'
```
- Manual
```
git clone https://github.com/tenfyzhong/tagbar-makefile.vim.git ~/.vim/bundle/tagbar-makefile.vim
echo 'set rtp+=~/.vim/bundle/tagbar-makefile.vim'
```

