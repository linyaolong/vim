# neco-look: look completion for neocomplcache/neocomplete/deoplete

A neocomplcache/neocomplete/deoplete plugin for `/usr/bin/look` for completing words in English.

## install

* Install the latest neocomplcache.vim/neocomplete.vim/deoplete.nvim
* Make sure if you already have `look` command
* Unarchive neco-look and put it into a dir of your &rtp.

## Author

Tatsuhiro Ujihisa
Shougo Matsushita

## License

GPL-3 or later
