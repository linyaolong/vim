[![SpaceVim home](https://spacevim.org/logo.png)](Home)
--
[Website](https://spacevim.org/)  
[Community](https://spacevim.org/community/)  
[FAQ](https://spacevim.org/faq/)  
[Layers](https://spacevim.org/layers/)

**Users**  
[Getting Help](Getting-help)  
[Docs](http://spacevim.org/documentation/)  
[Following HEAD](Following-HEAD)  

**Developers**  
[Contribute](https://spacevim.org/development/)  
[Tips & Tools](development-tips)  
[Code style](http://spacevim.org/conventions/)  
