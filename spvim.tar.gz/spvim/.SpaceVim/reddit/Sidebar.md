### SpaceVim

A community-driven vim distribution

[Introduction](https://spacevim.org/)   
[Community](https://spacevim.org/community/)  
[FAQ](https://github.com/SpaceVim/SpaceVim/wiki/FAQ)  
[Layers](https://spacevim.org/layers/)

**Users**  
[Install](https://github.com/SpaceVim/SpaceVim/wiki/Installing-SpaceVim)  
[Docs](http://spacevim.org/documentation/)

**Developers**  
[Contribute](https://spacevim.org/development/)  
[Tips & Tools](https://github.com/SpaceVim/SpaceVim/wiki/Development-tips)  
[Code style](http://spacevim.org/conventions/)  
