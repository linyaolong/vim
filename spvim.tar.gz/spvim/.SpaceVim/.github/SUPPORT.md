![Bountysource](https://spacevim.org/img/bountysource.png)

If you want to support SpaceVim, please check out our [Bountysource campaign](https://www.bountysource.com/teams/spacevim).

Also, you can buy me a coffee:

<a href='https://ko-fi.com/A538L6H' target='_blank'><img height='36' style='border:0px;height:36px;' src='https://az743702.vo.msecnd.net/cdn/kofi4.png?v=f' border='0' alt='Buy Me a Coffee at ko-fi.com' /></a>

| wechat                                                                   | alipay                                                                     |
| ------------------------------------------------------------------------ | -------------------------------------------------------------------------- |
| <img src="https://spacevim.org/img/weixin.png" height="150" width="150"> | <img src="https://spacevim.org/img/zhifubao.png" height="150" width="150"> |

Bitcoin: 1DtuVeg81c2L9NEhDaVTAAbrCR3pN5xPFv

# Current Sponsors

These are the companies or individuals contributing a monthly amount to help sustain SpaceVim's development.
See the [Bountysource campaign](https://www.bountysource.com/teams/spacevim) for more details.

| Date      | Description                                   |
| --------- | --------------------------------------------- |
| 2017-2-23 | user from wechat contributed ¥40 to SpaceVim  |
| 2017-2-14 | user from wechat contributed ¥100 to SpaceVim |
