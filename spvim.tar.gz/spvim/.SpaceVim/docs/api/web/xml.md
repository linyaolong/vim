---
title: "web#xml api"
description: "web#xml API provides some besic functions and values for parser xml file."
---

# [Available APIs](../../) >> web#xml

<!-- vim-markdown-toc GFM -->

- [Intro](#intro)
- [Functions](#functions)

<!-- vim-markdown-toc -->

## Intro

web#xml API provides some besic functions and values for parser xml file.

## Functions

| function name     | description     |
| ----------------- | --------------- |
| `parse(str)`      | parser content  |
| `parseFile(path)` | parse file path |
| `parseURL(url)`   | parse url       |
