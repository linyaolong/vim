---
title: "web#http api"
description: "web#http API provides some besic functions and values for http request"
---

# [Available APIs](../../) >> web#html

<!-- vim-markdown-toc GFM -->

- [Intro](#intro)
- [Functions](#functions)

<!-- vim-markdown-toc -->

## Intro

web#html API provides some besic functions and values for http request.

## Functions

| function name   | description        |
| --------------- | ------------------ |
| `get(url, ...)` | send a GET request |
